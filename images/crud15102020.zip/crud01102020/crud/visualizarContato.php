<?php 
    //Import do arquivo de Variaveis e Constantes
    require_once('modulo/config.php');

    //Import do arquivo de função para conectar no BD
    require_once('bd/conexaoMysql.php');

    //chama a função que vai estabelecer a conexão com o BD
    if(!$conex = conexaoMysql())
    {
        echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
        //die; //Finaliza a interpretação da página
    }

    $sql = "select tblcontatos.*, tblestados.sigla
            from tblcontatos, tblestados
            where tblestados.idEstado = tblcontatos.idEstado
            and tblcontatos.idContato = ".$id;

?>

<html>
    <head>
        <title>Visualizar Contato</title>
        <link rel="stylesheet" type="text/css" href="style/style.css">
    </head>
    <body>
    
        <table id="visualizarContato">
            <tr>
                <td>
                    Nome:
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Celular:
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Email:
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Estado:
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Data Nascimento
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Sexo:
                </td>
                <td>
                </td>
            </tr>
            <tr>
                <td>
                    Obs:
                </td>
                <td>
                </td>
            </tr>
        
        </table>
    
    </body>

</html>